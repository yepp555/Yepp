# Stride — Personal Fitness App

A free, dark-mode, mobile-first fitness tracker and installable Progressive Web App.

## Included in this version
- Dark interface with emerald accents, inspired by the screenshots
- Strength programs: Push, Pull, Legs, Full Body, and Upper Body
- Exercise-level set tracking for weight, reps/seconds, and completion
- Save completed strength sessions to workout history
- Log cardio, walks, runs, cycling, swimming, mobility, and other activities
- Weekly goal setting, active-minute totals, and current-day streak
- Monthly training calendar with completed sessions and planned sessions
- Weekly active-minutes chart and activity-type breakdown
- Optional body-weight log and trend chart
- JSON backup export/import and local data deletion
- Offline caching after the first successful hosted load

## Free hosting and iPhone installation
1. Create a GitHub repository named `stride-fitness`.
2. Upload all files in this folder to the repository root.
3. Go to **Settings → Pages**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
4. Open the published HTTPS URL in Safari on your iPhone.
5. Tap **Share → Add to Home Screen**. If available, enable **Open as Web App**, then tap **Add**.

You can open `index.html` locally to preview basic functionality. PWA installation and service-worker caching require HTTPS or localhost.

## Privacy and limits
All logs are stored locally in the browser on this device; there is no login, server, or automatic cloud sync. Export backups regularly. Clearing browser/site data may erase records. This is a personal tracking tool, not medical advice. Start conservatively and adjust exercise to your fitness and recovery.
